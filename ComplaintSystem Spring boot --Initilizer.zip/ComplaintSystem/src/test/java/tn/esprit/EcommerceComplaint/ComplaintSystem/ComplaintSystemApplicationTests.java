package tn.esprit.EcommerceComplaint.ComplaintSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
